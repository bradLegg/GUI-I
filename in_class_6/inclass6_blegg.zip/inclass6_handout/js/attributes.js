$(function() {
  //.attr()
  //.removeAttr()
  //.addClass()
  //.removeClass()

  // not sure why the heart icon on the top2 list items will not show up
  $('a#top').addClass('button');
  $('li#three').removeClass('hot');
  $('1i.hot').addClass('favorite');

});
