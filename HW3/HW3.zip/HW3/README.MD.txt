Link to github page: https://computerscienceman.github.io/GUI-I/HW3/
Link to github repository: https://github.com/computerScienceMan/GUI-I/

Bradley Legg - 7/31/2021 - GUI I - HW3
	In this assignment, I created a fully user-controlled, error-handled, dynamic 
	multiplication table. I displayed the table on a template for a webpage I am
	building as a side-project. I focused on providing all necessary details to 
	the user, to make the function more user-friendly.
	
	The part I had the most difficulty on was generating the table.
	The blank square in the upper left-most corner had me stumped for a while of 
	all things. I broke my solution to the problem down into three parts (1 for
	top rows, 1 for top cols, 1 for primary cells), which led me to the solution.

